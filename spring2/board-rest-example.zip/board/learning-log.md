# 매일 학습 기록

아래 양식을 날짜마다 복사하여 작성하고 코드와 함께 GitLab에 push합니다.
파일 내용은 예시가 아니라 실제 수행한 내용으로 채웁니다.

## YYYY-MM-DD

- 오늘 구현한 내용:
- API 요청 / 실제 응답 상태:
- 정상 입력 검증:
- 실패 입력 / 없는 id 검증:
- 테스트 실행 결과:
- 해결한 오류:
- 다음에 할 일:
- 커밋 메시지:

권장 진행 순서: Initializr + GitLab 최초 push → GET /post → GET /post/{id} → POST /post → PUT /post/{id} → DELETE /post/{id} → 통합 검증.
POST 전에는 DB가 비어 있으므로 목록 []와 상세 404부터 검증할 수 있습니다.
