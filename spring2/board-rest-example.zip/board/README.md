# Spring REST CRUD 게시판

VS Code에서 실행하는 Spring Boot 4.1.2 / Java 21 / Maven / JPA / H2 학습 프로젝트입니다.
완성본이므로 가이드의 단계별 실습을 직접 진행하려면 Initializr에서 새 프로젝트를 만드세요.

## 실행

프로젝트 폴더(이 README와 pom.xml이 있는 board)를 VS Code로 엽니다.
JDK 21을 설치하고 VS Code의 Extension Pack for Java, Spring Boot Extension Pack을 설치합니다.

Windows PowerShell:

```powershell
java -version
.\mvnw.cmd test
.\mvnw.cmd spring-boot:run
```

macOS / Linux:

```sh
chmod +x mvnw
./mvnw test
./mvnw spring-boot:run
```

브라우저에서 http://localhost:8080/ 에 접속합니다. HTML과 API는 같은 Spring 서버에서 제공합니다.
8080을 다른 앱이 쓰는 경우 Windows에서 다음처럼 실행하고 http://localhost:8082/ 에 접속합니다.

```powershell
.\mvnw.cmd spring-boot:run '-Dspring-boot.run.arguments=--server.port=8082'
```

## 요구 API

| 메서드 | 경로 | 성공 응답 |
|---|---|---|
| GET | /post | 200 JSON 배열, 최신 글 먼저 |
| GET | /post/{id} | 200 JSON 객체 |
| POST | /post | 201 JSON 객체 + Location 헤더 |
| PUT | /post/{id} | 200 수정한 JSON 객체 |
| DELETE | /post/{id} | 204, 응답 본문 없음 |

POST와 PUT 본문은 `{"title":"제목","content":"내용"}`입니다. PUT은 두 필드를 모두 전달하는 전체 수정입니다.
제목 1~100자, 내용 1~5000자이며 공백만 있는 값은 허용하지 않습니다. 잘못된 입력은 400, 없는 글은 404입니다.
오류 응답의 `message`를 확인하세요. `/api/posts` 경로는 사용하지 않습니다.

`api.http`는 VS Code REST Client 확장(선택 설치)으로 실행할 수 있습니다.
처음 POST를 실행한 뒤 응답 `id`를 파일 맨 위의 `@postId`에 넣습니다. 1이라고 가정하지 마세요.
수정, 삭제 후에는 GET을 다시 보내 DB 반영 여부를 확인합니다. DELETE 직후 같은 id 조회는404입니다.

## 구조

- `Post.java`: JPA 엔티티, 글 수정 메서드
- `PostRepository.java`: DB 접근
- `PostController.java`: 5개 REST 엔드포인트와 JSON 오류 처리
- `src/main/resources/static/`: fetch로 등록·목록·상세·수정·삭제하는 화면
- `PostApiTests.java`: CRUD 전체 흐름, 입력 검증, 없는 id, 잘못된 JSON 자동 테스트
- `learning-log.md`: 매일 구현 및 검증 기록 양식

H2는 메모리 DB이므로 서버를 완전히 종료하면 글이 사라집니다. Git은 코드와 기록을 저장하며 DB의 글을 저장하지 않습니다.
이 예제는 로컬 학습용이며 로그인과 권한 관리는 포함하지 않습니다.

## GitLab에 최초 업로드

GitLab에서 빈 프로젝트를 만들고 **Initialize repository with a README는 해제**합니다.
GitLab에 표시된 HTTPS Clone URL로 아래 따옴표 안의 안내 문구를 바꿉니다.
Git을 설치한 뒤 VS Code 터미널에서 실행합니다. 이름과 이메일도 자신의 정보로 바꿉니다.

```powershell
git init -b main
git config user.name "본인 이름"
git config user.email "본인 이메일"
git add .
git commit -m "feat: add board CRUD example"
git remote add origin "GitLab에서 복사한 실제 HTTPS 주소"
git push -u origin main
```

위 커밋 문구는 이 완성 ZIP을 처음 올릴 때의 예시입니다. 새 Initializr 프로젝트부터 시작한다면 `chore: initialize Spring Boot project`처럼 실제 변경에 맞게 작성하세요.
인증이 필요하면 Git Credential Manager의 안내를 따르거나 GitLab에서 발급한 토큰을 비밀번호 입력에 사용합니다.
토큰은 URL이나 파일에 적지 않습니다. 학교/회사 GitLab은 해당 서버의 인증 안내를 따릅니다.

## 매일 종료할 때

`learning-log.md`에 날짜·구현한 API·검증 결과·다음 할 일을 적습니다.

```powershell
.\mvnw.cmd test
git status
git diff
git add src api.http learning-log.md
git diff --cached
git commit -m "feat: 게시글 수정 API 구현"
git push
git status
```

새로 만든 파일이 있다면 `git status`에서 확인한 뒤 해당 경로도 `git add`합니다.
첫 push 이후에는 `git push`만 사용해도 됩니다. 바뀐 파일이 없으면 새 commit이 필요하지 않습니다.
최종적으로 GitLab의 Commits 화면에서 오늘의 커밋을 확인합니다. `target/`과 비밀번호·토큰은 커밋하지 않습니다.
