# REST 게시판 실습

Spring Boot 4.1.2 / Java 21 / Maven / VS Code

`pom.xml`이 있는 폴더에서 Windows는 `.\mvnw.cmd spring-boot:run`, macOS/Linux는 `chmod +x mvnw` 후 `./mvnw spring-boot:run`으로 실행합니다.

http://localhost:8080/ 에서 글을 등록하고 http://localhost:8080/api/posts 에서 JSON을 확인합니다. H2 메모리 DB는 서버 종료 시 초기화됩니다. 이 예제는 로컬 학습용으로 인증과 수정·삭제 기능은 포함하지 않습니다.

가이드: https://greenapple0101.github.io/spring2/index.html
