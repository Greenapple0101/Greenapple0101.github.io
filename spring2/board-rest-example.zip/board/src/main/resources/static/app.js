const API_URL = '/api/posts';
const form = document.querySelector('#post-form');
const posts = document.querySelector('#posts');
const status = document.querySelector('#status');
const submitButton = document.querySelector('#submit-button');

async function request(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { Accept: 'application/json', ...options.headers }
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || `요청 실패: HTTP ${response.status}`);
  }
  return response.json();
}

async function loadPosts() {
  const data = await request(API_URL);
  posts.replaceChildren();
  if (data.length === 0) {
    const empty = document.createElement('li');
    empty.textContent = '아직 등록된 글이 없습니다.';
    posts.append(empty);
    return;
  }
  for (const post of data) {
    const item = document.createElement('li');
    const title = document.createElement('h3');
    const content = document.createElement('p');
    title.textContent = `#${post.id} ${post.title}`;
    content.textContent = post.content;
    item.append(title, content);
    posts.append(item);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  submitButton.disabled = true;
  status.textContent = '저장 중...';
  try {
    const saved = await request(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: form.elements.namedItem('title').value.trim(),
        content: form.elements.namedItem('content').value.trim()
      })
    });
    form.reset();
    status.textContent = `${saved.id}번 글을 저장했습니다.`;
    await loadPosts();
  } catch (error) {
    status.textContent = error.message;
  } finally {
    submitButton.disabled = false;
  }
});

document.querySelector('#refresh-button').addEventListener('click', () => {
  status.textContent = '';
  loadPosts().catch(error => { status.textContent = error.message; });
});
loadPosts().catch(error => { status.textContent = error.message; });
