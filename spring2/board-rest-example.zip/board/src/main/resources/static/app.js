const API_URL = '/post';
const form = document.querySelector('#post-form');
const posts = document.querySelector('#posts');
const status = document.querySelector('#status');
const detail = document.querySelector('#detail');
const submitButton = document.querySelector('#submit-button');
const cancelButton = document.querySelector('#cancel-button');
let editingId = null;

async function request(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { Accept: 'application/json', ...options.headers }
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || `요청 실패: HTTP ${response.status}`);
  }
  // DELETE의 204 응답에는 JSON 본문이 없습니다.
  return response.status === 204 ? null : response.json();
}

async function run(action) {
  document.querySelectorAll('button').forEach(button => { button.disabled = true; });
  try {
    await action();
  } catch (error) {
    status.textContent = error.message;
  } finally {
    document.querySelectorAll('button').forEach(button => { button.disabled = false; });
  }
}

function resetForm() {
  editingId = null;
  form.reset();
  document.querySelector('#form-heading').textContent = '새 글 등록';
  submitButton.textContent = '등록 · POST';
  cancelButton.hidden = true;
}

function showDetail(post) {
  document.querySelector('#detail-title').textContent = `#${post.id} ${post.title}`;
  document.querySelector('#detail-content').textContent = post.content;
  detail.hidden = false;
}

function actionButton(label, action) {
  const button = document.createElement('button');
  button.type = 'button';
  button.textContent = label;
  button.addEventListener('click', () => run(action));
  return button;
}

async function loadPosts() {
  const data = await request(API_URL);
  posts.replaceChildren();
  if (data.length === 0) {
    const empty = document.createElement('li');
    empty.textContent = '아직 등록된 글이 없습니다. 첫 글을 등록하세요.';
    posts.append(empty);
    return;
  }
  for (const post of data) {
    const item = document.createElement('li');
    const title = document.createElement('h3');
    title.textContent = `#${post.id} ${post.title}`;
    const actions = document.createElement('div');
    actions.className = 'actions';
    actions.append(
      actionButton('상세 · GET', async () => {
        showDetail(await request(`${API_URL}/${post.id}`));
        status.textContent = `${post.id}번 글을 조회했습니다. (200 OK)`;
      }),
      actionButton('수정 · PUT', async () => {
        const current = await request(`${API_URL}/${post.id}`);
        editingId = current.id;
        form.elements.namedItem('title').value = current.title;
        form.elements.namedItem('content').value = current.content;
        document.querySelector('#form-heading').textContent = `${current.id}번 글 수정`;
        submitButton.textContent = '수정 저장 · PUT';
        cancelButton.hidden = false;
        form.elements.namedItem('title').focus();
        status.textContent = '제목과 내용을 수정한 뒤 저장하세요.';
      }),
      actionButton('삭제 · DELETE', async () => {
        await request(`${API_URL}/${post.id}`, { method: 'DELETE' });
        if (editingId === post.id) resetForm();
        detail.hidden = true;
        await loadPosts();
        status.textContent = `${post.id}번 글을 삭제했습니다. (204 No Content)`;
      })
    );
    item.append(title, actions);
    posts.append(item);
  }
}

form.addEventListener('submit', event => {
  event.preventDefault();
  run(async () => {
    const updating = editingId !== null;
    const saved = await request(updating ? `${API_URL}/${editingId}` : API_URL, {
      method: updating ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: form.elements.namedItem('title').value.trim(),
        content: form.elements.namedItem('content').value.trim()
      })
    });
    resetForm();
    showDetail(saved);
    await loadPosts();
    status.textContent = `${saved.id}번 글을 ${updating ? '수정' : '등록'}했습니다. (${updating ? '200 OK' : '201 Created'})`;
  });
});

cancelButton.addEventListener('click', () => { resetForm(); status.textContent = '수정을 취소했습니다.'; });
document.querySelector('#refresh-button').addEventListener('click', () => run(async () => {
  await loadPosts();
  status.textContent = '글 목록을 조회했습니다. (200 OK)';
}));
run(loadPosts);
