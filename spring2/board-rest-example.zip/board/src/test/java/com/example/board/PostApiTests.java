package com.example.board;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.datasource.url=jdbc:h2:mem:crudtest")
@AutoConfigureMockMvc
class PostApiTests {
    @Autowired MockMvc mvc;
    @Autowired PostRepository repository;

    @BeforeEach
    void clearPosts() {
        repository.deleteAll();
    }

    @Test
    void createReadUpdateDeleteCycle() throws Exception {
        mvc.perform(get("/post")).andExpect(status().isOk()).andExpect(content().json("[]"));
        String location = mvc.perform(post("/post").contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\" 첫 글 \",\"content\":\" 본문 \"}"))
                .andExpect(status().isCreated()).andExpect(header().exists("Location"))
                .andExpect(jsonPath("$.title").value("첫 글"))
                .andReturn().getResponse().getHeader("Location");
        mvc.perform(get("/post")).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(1)));
        mvc.perform(get(location)).andExpect(status().isOk()).andExpect(jsonPath("$.content").value("본문"));
        mvc.perform(put(location).contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"수정 제목\",\"content\":\"수정 본문\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.title").value("수정 제목"));
        mvc.perform(get(location)).andExpect(status().isOk()).andExpect(jsonPath("$.content").value("수정 본문"));
        mvc.perform(delete(location)).andExpect(status().isNoContent()).andExpect(content().string(""));
        mvc.perform(get(location)).andExpect(status().isNotFound()).andExpect(jsonPath("$.message").exists());
        mvc.perform(delete(location)).andExpect(status().isNotFound());
        mvc.perform(get("/post")).andExpect(status().isOk()).andExpect(content().json("[]"));
    }

    @Test
    void rejectsMissingBlankAndOversizeFields() throws Exception {
        String[] invalidBodies = {
            "{}",
            "{\"title\":\" \",\"content\":\"body\"}",
            "{\"title\":\"title\"}",
            "{\"title\":\"" + "a".repeat(101) + "\",\"content\":\"body\"}",
            "{\"title\":\"title\",\"content\":\"" + "a".repeat(5001) + "\"}"
        };
        for (String body : invalidBodies) {
            mvc.perform(post("/post").contentType(MediaType.APPLICATION_JSON).content(body))
                    .andExpect(status().isBadRequest()).andExpect(jsonPath("$.message").exists());
        }
        Post existing = repository.save(new Post("original", "body"));
        mvc.perform(put("/post/" + existing.getId()).contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"partial\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/post/" + existing.getId())).andExpect(jsonPath("$.title").value("original"));
    }

    @Test
    void missingPostsReturn404ForDetailUpdateAndDelete() throws Exception {
        String missing = "/post/9223372036854775807";
        mvc.perform(get(missing)).andExpect(status().isNotFound());
        mvc.perform(put(missing).contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"title\",\"content\":\"body\"}"))
                .andExpect(status().isNotFound());
        mvc.perform(delete(missing)).andExpect(status().isNotFound());
    }

    @Test
    void malformedJsonAndNonNumericIdReturn400() throws Exception {
        mvc.perform(post("/post").contentType(MediaType.APPLICATION_JSON).content("{broken"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.message").exists());
        mvc.perform(get("/post/not-a-number")).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").exists());
    }
}
